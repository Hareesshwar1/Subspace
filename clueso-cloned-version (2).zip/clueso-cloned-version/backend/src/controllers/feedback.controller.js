const Feedback = require("../models/Feedback");

/* CREATE */
exports.createFeedback = async (req, res) => {
  try {
    const feedback = await Feedback.create({
      userId: req.user.id,
      title: req.body.title,
      description: req.body.description,
      type: req.body.type
    });
    res.status(201).json(feedback);
  } catch (err) {
    res.status(500).json({ message: "Failed to create feedback" });
  }
};

/* READ */
exports.getFeedbacks = async (req, res) => {
  const feedbacks = await Feedback.find({ userId: req.user.id });
  res.json(feedbacks);
};

/* DELETE */
exports.deleteFeedback = async (req, res) => {
  await Feedback.findByIdAndDelete(req.params.id);
  res.json({ message: "Feedback deleted" });
};
