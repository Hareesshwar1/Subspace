const Feedback = require("../models/Feedback");

exports.getAIInsights = async (req, res) => {
  try {
    // 1️⃣ Get user's feedbacks
    const feedbacks = await Feedback.find({ userId: req.user.id });

    if (!feedbacks.length) {
      return res.json({
        sentiment: "Neutral",
        score: 0,
        summary: "No feedback available yet.",
        insights: []
      });
    }

    // 2️⃣ Combine all feedback text
    const text = feedbacks
      .map(f => `${f.title} ${f.description}`)
      .join(" ")
      .toLowerCase();

    // 3️⃣ Simple sentiment logic (mock AI)
    let sentiment = "Neutral";
    let score = 50;

    if (text.includes("slow") || text.includes("confusing") || text.includes("bug")) {
      sentiment = "Negative";
      score = 30;
    }

    if (text.includes("good") || text.includes("smooth") || text.includes("easy")) {
      sentiment = "Positive";
      score = 80;
    }

    // 4️⃣ Insights generation
    const insights = [];

    if (text.includes("onboarding")) {
      insights.push("Improve onboarding experience");
    }

    if (text.includes("cta") || text.includes("button")) {
      insights.push("CTA visibility impacts conversions");
    }

    if (text.includes("video")) {
      insights.push("Video feedback increases trust");
    }

    // 5️⃣ Final response
    res.json({
      sentiment,
      score,
      summary: `Based on ${feedbacks.length} feedback entries.`,
      insights
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "AI insight generation failed" });
  }
};
