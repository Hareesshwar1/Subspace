const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth.middleware");

// Protected route
router.get("/me", auth, (req, res) => {
  res.json({
    message: "Protected data accessed",
    userId: req.user.id
  });
});

module.exports = router;
