const express = require("express");
const router = express.Router();

const auth = require("../middlewares/auth.middleware");
const feedbackController = require("../controllers/feedback.controller");

/* CREATE feedback */
router.post("/", auth, feedbackController.createFeedback);

/* GET feedbacks */
router.get("/", auth, feedbackController.getFeedbacks);

/* DELETE feedback */
router.delete("/:id", auth, feedbackController.deleteFeedback);

module.exports = router;
