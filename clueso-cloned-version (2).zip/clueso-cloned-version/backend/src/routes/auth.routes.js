const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth.middleware");
const { getAIInsights } = require("../controllers/ai.controller");
// CONTROLLERS
const {
  signup,
  login,
   verifyOtp,
  googleLogin,
  ssoLogin
} = require("../controllers/auth.controller");

// ================= AUTH ROUTES =================

// Email / Password
router.post("/signup", signup);
router.post("/login", login);
router.post("/verify-otp", verifyOtp);
router.get("/insights", auth, getAIInsights);
// Google OAuth (placeholder – next step)
router.post("/google", googleLogin);

// SSO (Enterprise / SAML – placeholder)
router.post("/sso", ssoLogin);

module.exports = router;
