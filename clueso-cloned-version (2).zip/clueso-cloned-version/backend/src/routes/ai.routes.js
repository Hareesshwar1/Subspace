const express = require("express");
const router = express.Router();

const { getAIInsights } = require("../controllers/ai.controller");
const auth = require("../middlewares/auth.middleware");

// POST /api/ai/insights
router.post("/insights", auth, getAIInsights);

module.exports = router;
