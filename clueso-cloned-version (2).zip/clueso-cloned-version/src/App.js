import { BrowserRouter, Routes, Route } from "react-router-dom";

/* COMMON */
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";

/* LANDING PAGE COMPONENTS */
import Hero from "./components/Hero";
import Logos from "./components/Logos";
import Features from "./components/Features";
import Demo from "./components/Demo";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import Matrix from "./components/Matrix";
import Avatars from "./components/Avatars";
import Workflow from "./components/Workflow";
import UseCases from "./components/UseCases";
import Distribution from "./components/Distribution";
import Trust from "./components/Trust";
import Story from "./components/Story";
import EditorPreview from "./components/EditorPreview";
import InteractiveMatrix from "./components/InteractiveMatrix";
import StickyEditor from "./components/StickyEditor";
import ScrollStage from "./components/ScrollStage";
import AnimatedGrid from "./components/AnimatedGrid";
import ImpactMatrix from "./components/ImpactMatrix";

/* PAGES */
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Feedback from "./pages/Feedback";

/* ---------------- LANDING PAGE ---------------- */
function LandingPage() {
  return (
    <>
      <ScrollStage hero={<Hero />} editor={<StickyEditor />} />

      <Logos />
      <Features />
      <Matrix />
      <Avatars />
      <Story />
      <AnimatedGrid />
      <ImpactMatrix />
      <Workflow />
      <InteractiveMatrix />
      <EditorPreview />
      <UseCases />
      <Distribution />
      <Trust />
      <Demo />
      <CTA />
      <Footer />
    </>
  );
}

/* ---------------- APP ---------------- */
function App() {
  return (
    <BrowserRouter>
      {/* GLOBAL NAVBAR */}
      <Navbar />

      <Routes>
        {/* PUBLIC ROUTES */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* PROTECTED ROUTES */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/feedback"
          element={
            <ProtectedRoute>
              <Feedback />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
