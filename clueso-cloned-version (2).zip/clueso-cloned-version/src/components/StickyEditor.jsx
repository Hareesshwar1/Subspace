import "./StickyEditor.css";
import { useEffect, useRef, useState } from "react";

const steps = [
  {
    title: "Write the script",
    desc: "Turn feedback into a clear video script in minutes."
  },
  {
    title: "Choose an avatar",
    desc: "Pick a presenter and voice for your video."
  },
  {
    title: "Edit the timeline",
    desc: "Trim scenes and refine your message."
  },
  {
    title: "Publish everywhere",
    desc: "Embed or share videos across all channels."
  }
];

function StickyEditor() {
  const sectionRef = useRef(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!sectionRef.current) return;

      const rect = sectionRef.current.getBoundingClientRect();
      const totalHeight = rect.height - window.innerHeight;
      const progress = Math.min(
        Math.max(-rect.top / totalHeight, 0),
        1
      );

      const stepIndex = Math.floor(progress * steps.length);
      setActive(Math.min(stepIndex, steps.length - 1));
    };

    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section ref={sectionRef} className="sticky-editor">
      <div className="sticky-inner">
        {/* LEFT TEXT */}
        <div className="sticky-text">
  <div className="editor-text">
    <h2>{steps[active].title}</h2>
    <p>{steps[active].desc}</p>
  </div>
</div>

        {/* RIGHT PREVIEW */}
        <div className="sticky-preview">
          <div className="preview-box">
            {steps[active].title}
          </div>
        </div>
      </div>
    </section>
  );
}

export default StickyEditor;
