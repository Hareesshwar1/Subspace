import MatrixCard from "./MatrixCard";
import "./ImpactMatrix.css";

function ImpactMatrix() {
  return (
    <section className="impact-matrix">
      <h2>The Frequency × Impact Matrix</h2>
      <p className="subtitle">Prioritizing which videos to work on first</p>

      <div className="matrix-grid">
        <MatrixCard
          title="Make video ASAP"
          subtitle="High impact and high frequency"
          variant="asap"
        />

        <MatrixCard
          title="Optional deep-dive video"
          subtitle="High impact and low frequency"
          variant="deep"
        />

        <MatrixCard
          title="Consider FAQ format"
          subtitle="Low impact and high frequency"
          variant="faq"
        />

        <MatrixCard
          title="Ignore for now"
          subtitle="Low impact and low frequency"
          variant="ignore"
        />
      </div>
    </section>
  );
}

export default ImpactMatrix;
