// src/components/AnimatedGrid.jsx
import AnimatedCard from "./AnimatedCard";
import "./AnimatedGrid.css";

import gif1 from "../assets/gifs/demo1.gif";
import gif2 from "../assets/gifs/demo2.gif";
import gif3 from "../assets/gifs/demo3.gif";

function AnimatedGrid() {
  const items = [gif1, gif2, gif3, gif1, gif2, gif3];

  return (
    <section className="animated-grid">
      {items.map((gif, i) => (
        <AnimatedCard key={i} src={gif} delay={i * 0.12} />
      ))}
    </section>
  );
}

export default AnimatedGrid;
