import "./UseCases.css";
import { motion } from "framer-motion";

const cases = [
  {
    title: "Marketing teams",
    points: [
      "Create landing page videos",
      "Explain features visually",
      "Increase conversion rates"
    ]
  },
  {
    title: "Product teams",
    points: [
      "Product walkthroughs",
      "Feature announcements",
      "Release explanations"
    ]
  },
  {
    title: "Sales teams",
    points: [
      "Personalized demo videos",
      "Customer follow-ups",
      "Short explainer clips"
    ]
  }
];

function UseCases() {
  return (
    <section className="usecases">
      <h2>Built for every team</h2>
      <p className="subtitle">
        See how different teams use Clueso to create impact.
      </p>

      <div className="usecase-grid">
        {cases.map((item, i) => (
          <motion.div
            key={i}
            className="usecase-card"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            viewport={{ once: true }}
          >
            <h3>{item.title}</h3>
            <ul>
              {item.points.map((p, idx) => (
                <li key={idx}>{p}</li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default UseCases;
