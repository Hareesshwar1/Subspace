import "./Distribution.css";
import { motion } from "framer-motion";

const channels = [
  {
    title: "Website embeds",
    desc: "Embed videos seamlessly on landing pages and blogs."
  },
  {
    title: "Docs & knowledge base",
    desc: "Use videos inside documentation and help articles."
  },
  {
    title: "Sales & email",
    desc: "Share videos in sales follow-ups and outreach emails."
  },
  {
    title: "Social & internal tools",
    desc: "Share links across Slack, Notion and social platforms."
  }
];

function Distribution() {
  return (
    <section className="distribution">
      <h2>Share videos everywhere</h2>
      <p className="subtitle">
        Publish once and distribute across all your channels.
      </p>

      <div className="distribution-grid">
        {channels.map((item, i) => (
          <motion.div
            key={i}
            className="distribution-card"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            viewport={{ once: true }}
          >
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default Distribution;
