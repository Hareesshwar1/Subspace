import "./ScrollStage.css";
import { useEffect, useRef, useState } from "react";

function clamp(v, min = 0, max = 1) {
  return Math.min(Math.max(v, min), max);
}

function ScrollStage({ hero, editor }) {
  const ref = useRef(null);
  const [p, setP] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!ref.current) return;
      const r = ref.current.getBoundingClientRect();
      const total = r.height - window.innerHeight;
      setP(clamp(-r.top / total));
    };

    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section ref={ref} className="scroll-stage">
      {/* HERO */}
      <div className="layer hero-layer">
        <div
          style={{
            opacity: p < 0.25 ? 1 : 0,
            background: "rgba(255,0,0,0.05)"
          }}
        >
          {hero}
        </div>
      </div>

      {/* EDITOR */}
      <div className="layer editor-layer">
        {editor}
      </div>
    </section>
  );
}

export default ScrollStage;
