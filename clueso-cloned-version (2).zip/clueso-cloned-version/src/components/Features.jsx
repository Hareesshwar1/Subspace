import "./Features.css";
import { motion } from "framer-motion";

const items = [
  {
    title: "AI avatars",
    desc: "Create professional videos using AI-generated presenters.",
    tag: "NEW"
  },
  {
    title: "Video editor",
    desc: "Edit, trim and enhance videos directly in your browser."
  },
  {
    title: "Insights & prioritization",
    desc: "Decide which videos to create using impact frameworks."
  },
  {
    title: "Embeds & sharing",
    desc: "Share videos across landing pages, docs and emails."
  }
];

function Features() {
  return (
    <section className="features-v2">
      <h2>Everything you need to scale video content</h2>

      <div className="features-grid">
        {items.map((item, i) => (
          <motion.div
            key={i}
            className="feature-card"
            whileHover={{ y: -6 }}
            transition={{ duration: 0.25 }}
          >
            {item.tag && <span className="tag">{item.tag}</span>}
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default Features;
