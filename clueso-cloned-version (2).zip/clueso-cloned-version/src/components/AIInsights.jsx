import { useState } from "react";

function AIInsights() {
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState(null);
  const [error, setError] = useState("");

  const generateInsights = async () => {
    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");

      const res = await fetch("http://localhost:5000/api/ai/insights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        }
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "AI failed");
      }

      setInsight(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ marginTop: "30px" }}>
      <h2>AI Insights</h2>

      <button onClick={generateInsights} disabled={loading}>
        {loading ? "Analyzing..." : "Generate AI Insights"}
      </button>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {insight && (
        <div style={{ marginTop: "20px", padding: "16px", border: "1px solid #ddd", borderRadius: "8px" }}>
          <p><strong>Sentiment:</strong> {insight.sentiment}</p>
          <p><strong>Summary:</strong> {insight.summary}</p>
          <p><strong>Score:</strong> {insight.score}</p>
        </div>
      )}
    </div>
  );
}

export default AIInsights;
