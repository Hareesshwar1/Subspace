import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-left">
        <strong>Clueso</strong>
        <p>© 2025 Clueso. All rights reserved.</p>
      </div>

      <div className="footer-right">
        <a href="/">Privacy</a>
        <a href="/">Terms</a>
        <a href="/">Contact</a>
      </div>
    </footer>
  );
}

export default Footer;
