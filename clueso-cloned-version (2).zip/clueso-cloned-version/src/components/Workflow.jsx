import "./Workflow.css";
import { motion } from "framer-motion";

// GIFS
import createGif from "../assets/workflow/create.gif";
import editGif from "../assets/workflow/edit.gif";
import publishGif from "../assets/workflow/publish.gif";

const steps = [
  {
    step: "01",
    title: "Create",
    desc: "Generate videos using AI avatars or scripts in minutes.",
    media: createGif
  },
  {
    step: "02",
    title: "Edit",
    desc: "Trim, rearrange and refine videos using a built-in editor.",
    media: editGif
  },
  {
    step: "03",
    title: "Publish",
    desc: "Export or embed videos across websites, docs and campaigns.",
    media: publishGif
  }
];

function Workflow() {
  return (
    <section className="workflow" id="workflow">
      <h2>Create. Edit. Publish.</h2>

      <p className="workflow-subtitle">
        Everything you need to produce high-quality videos in one place.
      </p>

      <div className="workflow-steps">
        {steps.map((item, i) => (
          <motion.div
            key={i}
            className="workflow-card"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: i * 0.15 }}
            viewport={{ once: true }}
          >
            {/* MEDIA */}
            <div className="workflow-media">
              <img src={item.media} alt={item.title} />
            </div>

            <span className="step">{item.step}</span>
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default Workflow;
