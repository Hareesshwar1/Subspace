function MatrixCard({ title, subtitle, variant }) {
  return (
    <div className={`matrix-card ${variant}`}>
      <div className="matrix-visual" />
      <h3>{title}</h3>
      <p>{subtitle}</p>
    </div>
  );
}

export default MatrixCard;
