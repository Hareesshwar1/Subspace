import "./Demo.css";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 60 },
  visible: { opacity: 1, y: 0 }
};

function Demo() {
  return (
    <motion.section
      className="demo"
      variants={fadeUp}
      initial="hidden"
      whileInView="visible"
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
    >
      <div className="demo-left">
        <h2>How Clueso works</h2>
        <ul>
          <li><span>1</span>Collect video testimonials</li>
          <li><span>2</span>Manage them in one place</li>
          <li><span>3</span>Share everywhere</li>
        </ul>
      </div>

      <div className="demo-right">
        <div className="demo-placeholder">Demo Preview</div>
      </div>
    </motion.section>
  );
}

export default Demo;
