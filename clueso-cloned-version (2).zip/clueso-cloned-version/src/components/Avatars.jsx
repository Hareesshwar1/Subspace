import "./Avatars.css";
import { motion } from "framer-motion";

function Avatars() {
  return (
    <section className="avatars">
      <div className="avatars-left">
        <h2>Create videos without cameras or studios</h2>
        <p>
          Use AI avatars to create professional videos in minutes.
          No recording, no retakes, no editing skills required.
        </p>

        <ul>
          <li> Natural-sounding voices</li>
          <li> Professional presenters</li>
          <li> Instant generation</li>
        </ul>

        <button className="primary-btn">Try AI avatars</button>
      </div>

      <motion.div
        className="avatars-right"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        <div className="avatar-placeholder">
          AI Avatar Preview
        </div>
      </motion.div>
    </section>
  );
}

export default Avatars;
