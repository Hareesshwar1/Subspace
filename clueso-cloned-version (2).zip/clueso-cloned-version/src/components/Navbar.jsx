import "./Navbar.css";
import { useNavigate } from "react-router-dom";
import {
  FiPlay,
  FiFileText,
  FiTrendingUp,
  FiGlobe,
  FiMic,
  FiImage,
  FiEdit,
  FiHelpCircle,
  FiUsers,
  FiType,
  FiMessageCircle
} from "react-icons/fi";

function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  // Sign in button click
  const handleSignIn = () => {
    if (token) {
      navigate("/dashboard"); // logged in → dashboard
    } else {
      navigate("/login"); // not logged in → login
    }
  };

  // Logo click → landing page
  const goHome = () => {
    navigate("/");
  };

  return (
    <header className="navbar">
      {/* LEFT */}
      <div
        className="nav-left"
        onClick={goHome}
        style={{ cursor: "pointer" }}
      >
        <img
          src={require("../assets/images/clueso-logo.png")}
          alt="Clueso"
          className="nav-logo"
        />
        <span className="nav-brand">Clueso</span>
      </div>

      {/* CENTER */}
      <nav className="nav-center">
        {/* PRODUCT */}
        <div className="nav-item dropdown">
          <button className="nav-btn">
            Product <span className="chevron">⌄</span>
          </button>

          <div className="dropdown-menu product-menu">
            <div className="dropdown-col">
              <p className="dropdown-title">Capabilities</p>

              <button className="dropdown-link">
                <FiPlay className="icon" />
                <div>
                  <strong>Videos</strong>
                  <span>Studio style videos for any product</span>
                </div>
              </button>

              <button className="dropdown-link">
                <FiFileText className="icon" />
                <div>
                  <strong>Documentation</strong>
                  <span>Step by step articles with screenshots</span>
                </div>
              </button>

              <div className="dropdown-highlight">
                <FiTrendingUp className="icon" />
                <div>
                  <strong>Changelog</strong>
                  <span>See what’s new in Clueso</span>
                </div>
              </div>
            </div>

            <div className="dropdown-col">
              <p className="dropdown-title">Features</p>

              <button className="dropdown-link">
                <FiGlobe className="icon" />
                <div>
                  <strong>Translate</strong>
                  <span>Translate your videos and docs</span>
                </div>
              </button>

              <button className="dropdown-link">
                <FiMic className="icon" />
                <div>
                  <strong>AI Voiceovers</strong>
                  <span>Translate your videos and docs</span>
                </div>
              </button>

              <button className="dropdown-link">
                <FiImage className="icon" />
                <div>
                  <strong>Slides to video</strong>
                  <span>Convert static slides into videos</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* RESOURCES */}
        <div className="nav-item dropdown">
          <button className="nav-btn">
            Resources <span className="chevron">⌄</span>
          </button>

          <div className="dropdown-menu resources-menu">
            <button className="dropdown-link">
              <FiEdit className="icon" />
              <div>
                <strong>Blog</strong>
                <span>Latest news and practical guides</span>
              </div>
            </button>

            <button className="dropdown-link">
              <FiHelpCircle className="icon" />
              <div>
                <strong>Help Center</strong>
                <span>Learn how to use Clueso</span>
              </div>
            </button>

            <button className="dropdown-link">
              <FiUsers className="icon" />
              <div>
                <strong>Customer Stories</strong>
                <span>Hear from our customers</span>
              </div>
            </button>

            <button className="dropdown-link">
              <FiType className="icon" />
              <div>
                <strong>
                  Video Glossary <span className="badge">New</span>
                </strong>
                <span>All things video production</span>
              </div>
            </button>

            <button className="dropdown-link">
              <FiMessageCircle className="icon" />
              <div>
                <strong>FAQs</strong>
                <span>Frequently asked questions</span>
              </div>
            </button>
          </div>
        </div>

        <button className="nav-btn">Pricing</button>
        <button className="nav-btn">Careers</button>
      </nav>

      {/* RIGHT */}
      <div className="nav-right">
        {/* ALWAYS SIGN IN (Clueso style) */}
        <button className="btn-outline" onClick={handleSignIn}>
          Sign in
        </button>

        <button className="btn-solid">Start Free Trial</button>
      </div>
    </header>
  );
}

export default Navbar;
