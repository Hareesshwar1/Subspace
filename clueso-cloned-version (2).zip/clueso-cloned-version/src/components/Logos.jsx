import "./Logos.css";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 60 },
  visible: { opacity: 1, y: 0 }
};

function Logos() {
  return (
    <motion.section
      className="logos"
      variants={fadeUp}
      initial="hidden"
      whileInView="visible"
      transition={{ duration: 0.8, ease: "easeOut" }}
      viewport={{ once: true }}
    >
      <p className="logos-text">Trusted by teams worldwide</p>

      <div className="logos-row">
        <span>CompanyOne</span>
        <span>StartupX</span>
        <span>TechFlow</span>
        <span>Brandly</span>
        <span>NextCorp</span>
      </div>
    </motion.section>
  );
}

export default Logos;
