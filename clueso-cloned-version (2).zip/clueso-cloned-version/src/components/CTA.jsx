import "./CTA.css";
import { motion } from "framer-motion";

function CTA() {
  return (
    <motion.section
      className="cta"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
    >
      <h2>Ready to collect video testimonials?</h2>
      <p>Start building trust and boosting conversions today.</p>
      <button className="cta-main">Get started for free</button>
    </motion.section>
  );
}

export default CTA;
