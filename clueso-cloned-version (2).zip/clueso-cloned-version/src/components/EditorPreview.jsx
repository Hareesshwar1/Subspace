import "./EditorPreview.css";
import { useState } from "react";

const panels = [
  { id: "script", label: "Script", desc: "Edit video script line by line" },
  { id: "avatar", label: "Avatar", desc: "Choose presenter and voice" },
  { id: "timeline", label: "Timeline", desc: "Trim and arrange scenes" },
  { id: "export", label: "Export", desc: "Embed or share anywhere" }
];

function EditorPreview() {
  const [active, setActive] = useState("script");

  return (
    <section className="editor">
      <h2>Everything happens inside one editor</h2>
      <p className="editor-sub">
        Create, edit and publish videos without switching tools.
      </p>

      <div className="editor-shell">
        <div className="editor-sidebar">
          {panels.map(p => (
            <button
              key={p.id}
              className={active === p.id ? "tab active" : "tab"}
              onMouseEnter={() => setActive(p.id)}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="editor-canvas">
          {panels.map(p => (
            active === p.id && (
              <div key={p.id} className="canvas-card">
                <h3>{p.label}</h3>
                <p>{p.desc}</p>
              </div>
            )
          ))}
        </div>
      </div>
    </section>
  );
}

export default EditorPreview;
