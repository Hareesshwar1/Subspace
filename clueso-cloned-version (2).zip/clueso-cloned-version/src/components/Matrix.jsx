import "./Matrix.css";

function Matrix() {
  return (
    <section className="matrix">
      <h2>The Frequency × Impact Matrix</h2>
      <p className="subtitle">
        Prioritizing which videos to work on first
      </p>

      <div className="matrix-grid">
        <div className="cell pink">
          <h3>Make video ASAP</h3>
          <p>High impact and high frequency</p>
        </div>

        <div className="cell green">
          <h3>Optional deep-dive video</h3>
          <p>High impact and low frequency</p>
        </div>

        <div className="cell beige">
          <h3>Consider FAQ format</h3>
          <p>Low impact and high frequency</p>
        </div>

        <div className="cell blue">
          <h3>Ignore for now</h3>
          <p>Low impact and low frequency</p>
        </div>
      </div>
    </section>
  );
}

export default Matrix;
