import "./Trust.css";
import { motion } from "framer-motion";

const testimonials = [
  {
    quote:
      "Clueso helped us scale product videos without increasing our team size.",
    author: "Head of Product"
  },
  {
    quote:
      "We replaced long docs with short videos and saw better engagement.",
    author: "Growth Lead"
  },
  {
    quote:
      "The workflow makes video creation incredibly fast and consistent.",
    author: "Marketing Manager"
  }
];

function Trust() {
  return (
    <section className="trust">
      <h2>Trusted by modern teams</h2>
      <p className="subtitle">
        Teams use Clueso to create and scale video content efficiently.
      </p>

      <div className="trust-grid">
        {testimonials.map((item, i) => (
          <motion.div
            key={i}
            className="trust-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            viewport={{ once: true }}
          >
            <p className="quote">“{item.quote}”</p>
            <span className="author">— {item.author}</span>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default Trust;
