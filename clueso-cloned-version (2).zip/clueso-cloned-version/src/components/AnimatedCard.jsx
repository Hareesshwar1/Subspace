import { motion } from "framer-motion";

function AnimatedCard({ src, delay = 0 }) {
  return (
    <motion.div
      className="animated-card"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.6,
        delay,
        ease: "easeOut"
      }}
    >
      <img src={src} alt="preview" />
    </motion.div>
  );
}

export default AnimatedCard;
