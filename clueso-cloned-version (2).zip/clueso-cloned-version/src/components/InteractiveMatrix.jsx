import "./InteractiveMatrix.css";
import { useState } from "react";

const quadrants = [
  {
    id: "q1",
    title: "Make video ASAP",
    desc: "High frequency and high impact feedback deserves immediate videos."
  },
  {
    id: "q2",
    title: "Deep-dive video",
    desc: "High impact but low frequency topics benefit from in-depth videos."
  },
  {
    id: "q3",
    title: "FAQ format",
    desc: "High frequency but low impact feedback works well as short FAQs."
  },
  {
    id: "q4",
    title: "Ignore for now",
    desc: "Low impact and low frequency items can be deprioritized."
  }
];

function InteractiveMatrix() {
  const [active, setActive] = useState(null);

  return (
    <section className="matrix">
      <h2>Prioritize what to turn into videos</h2>
      <p className="matrix-sub">
        Use the Frequency × Impact framework to decide faster.
      </p>

      <div className="matrix-wrap">
        <div className="matrix-grid">
          {quadrants.map(q => (
            <div
              key={q.id}
              className={
                active === q.id ? "matrix-cell active" : "matrix-cell"
              }
              onMouseEnter={() => setActive(q.id)}
              onMouseLeave={() => setActive(null)}
            >
              <h4>{q.title}</h4>
            </div>
          ))}
        </div>

        <div className="matrix-info">
          {active ? (
            <>
              <h3>{quadrants.find(q => q.id === active).title}</h3>
              <p>{quadrants.find(q => q.id === active).desc}</p>
            </>
          ) : (
            <p className="hint">
              Hover over a quadrant to see when to create videos.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

export default InteractiveMatrix;
