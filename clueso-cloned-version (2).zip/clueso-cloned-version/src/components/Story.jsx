import "./Story.css";

function Story() {
  return (
    <section className="story">
      <h2>From feedback to video — fast</h2>

      <div className="story-steps">
        <div className="story-card">
          <span className="story-step">01</span>
          <h3>Collect feedback</h3>
          <p>
            Feedback comes from sales calls, support tickets,
            and customer conversations.
          </p>
        </div>

        <div className="story-card highlight">
          <span className="story-step">02</span>
          <h3>Find insights</h3>
          <p>
            Use frameworks like Frequency × Impact to
            decide what matters most.
          </p>
        </div>

        <div className="story-card">
          <span className="story-step">03</span>
          <h3>Create videos</h3>
          <p>
            Turn insights into short, clear videos that
            scale across teams.
          </p>
        </div>
      </div>
    </section>
  );
}

export default Story;
