import "./Hero.css";

function Hero() {
  const scrollToWorkflow = () => {
  const section = document.getElementById("workflow");
  section?.scrollIntoView({ behavior: "smooth" });
};

  return (
    
    <section className="hero">
      <div className="hero-content">
    <div className="hero-content">
  <div className="hero-text">
    <h1>
      Turn customer feedback <br />
      into videos
    </h1>

    <p>
      Collect, manage and share authentic video testimonials
      to grow trust and conversions.
    </p>

    <div className="hero-actions">
     <button
  className="primary-btn"
  onClick={scrollToWorkflow}
>
  Get started
</button>

      <button className="secondary-btn">Book a demo</button>
    </div>
  </div>
</div>

        
        <h1>
          Turn customer feedback <br />
          into videos
        </h1>

        <p>
          Collect, manage and share authentic video testimonials
          to grow trust and conversions.
        </p>

        <div className="hero-actions">
          <button className="primary-btn">Get started</button>
          <button className="secondary-btn">Book a demo</button>
        </div>
      </div>
    </section>
  );
}

export default Hero;
