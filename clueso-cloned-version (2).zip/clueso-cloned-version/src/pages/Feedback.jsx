import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";

function Feedback() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("text");
  const [feedbacks, setFeedbacks] = useState([]);
  const [error, setError] = useState("");

  // 📥 Fetch feedbacks
  const fetchFeedbacks = useCallback(async () => {
    try {
      const res = await fetch("http://localhost:5000/api/feedback", {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      const data = await res.json();

      // ✅ FIX: ensure array always
      if (Array.isArray(data)) {
        setFeedbacks(data);
      } else if (Array.isArray(data.feedbacks)) {
        setFeedbacks(data.feedbacks);
      } else {
        setFeedbacks([]);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load feedbacks");
      setFeedbacks([]);
    }
  }, [token]);

  // 🔒 Protect route
  useEffect(() => {
    if (!token) {
      navigate("/login");
    } else {
      fetchFeedbacks();
    }
  }, [token, navigate, fetchFeedbacks]);

  // ➕ Submit feedback
  const submitFeedback = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const res = await fetch("http://localhost:5000/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ title, description, type })
      });

      if (!res.ok) throw new Error();

      setTitle("");
      setDescription("");
      setType("text");

      // refresh list
      fetchFeedbacks();
    } catch {
      setError("Failed to submit feedback");
    }
  };

  return (
    <div style={{ padding: "40px", maxWidth: "600px" }}>
      <h1>Feedback</h1>

      <form onSubmit={submitFeedback}>
        <input
          placeholder="Title"
          value={title}
          required
          onChange={(e) => setTitle(e.target.value)}
        />

        <textarea
          placeholder="Description"
          value={description}
          required
          onChange={(e) => setDescription(e.target.value)}
        />

        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="text">Text</option>
          <option value="video">Video</option>
        </select>

        <button type="submit">Submit</button>
      </form>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <h3>Your Feedback</h3>

      {feedbacks.length === 0 && <p>No feedback yet</p>}

      {feedbacks.map((f) => (
        <div key={f._id} style={{ borderBottom: "1px solid #ddd", marginBottom: "10px" }}>
          <strong>{f.title}</strong>
          <p>{f.description}</p>
          <small>Type: {f.type}</small>
        </div>
      ))}
    </div>
  );
}

export default Feedback;
