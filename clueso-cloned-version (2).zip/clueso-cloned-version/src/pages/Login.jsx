import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/login.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  // 🔐 Email + Password Login
  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "Login failed");
      }

      // ✅ Save JWT
      localStorage.setItem("token", data.token);

      // ✅ Redirect to dashboard
      navigate("/dashboard");
    } catch (err) {
      setError(err.message || "Server error");
    } finally {
      setLoading(false);
    }
  };

  // 🔵 Google Login (mock / backend-ready)
  const handleGoogleLogin = () => {
    // If backend Google OAuth exists, keep this:
    // window.location.href = "http://localhost:5000/api/auth/google";

    // ✅ MOCK (acceptable for assignment)
    localStorage.setItem("token", "mock-google-token");
    navigate("/dashboard");
  };

  // 🔵 SSO Login (mock)
  const handleSSOLogin = () => {
    localStorage.setItem("token", "mock-sso-token");
    navigate("/dashboard");
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <img
          src={require("../assets/images/clueso-logo.png")}
          alt="Clueso"
          className="login-logo"
        />

        <h2>Log in to Clueso</h2>

        {/* OAuth buttons */}
        <button className="oauth-btn google" onClick={handleGoogleLogin}>
          Sign in with Google
        </button>

        <button className="oauth-btn sso" onClick={handleSSOLogin}>
          Sign in with SSO
        </button>

        <div className="divider">
          <span>OR</span>
        </div>

        {error && <p className="error">{error}</p>}

        {/* Email Login */}
        <form onSubmit={handleLogin}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <div className="password-row">
            <label>Password</label>
            <span className="forgot">Forgot password?</span>
          </div>

          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? "Logging in..." : "Log in with email"}
          </button>
        </form>

        <p className="signup-text">
          Don’t have an account?{" "}
          <span onClick={() => navigate("/signup")}>Sign up</span>
        </p>
      </div>
    </div>
  );
}

export default Login;
