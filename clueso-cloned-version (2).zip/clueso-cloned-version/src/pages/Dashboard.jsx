import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState(null);
  const [error, setError] = useState("");

  // 🔒 Protect dashboard
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
    }
  }, [navigate]);

  // 🚪 Logout
  const logout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  // 🤖 Generate AI Insights
  const generateAIInsights = async () => {
    setLoading(true);
    setError("");
    setInsight(null);

    try {
      const token = localStorage.getItem("token");

      const res = await fetch("http://localhost:5000/api/ai/insights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        }
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "AI generation failed");
      }

      setInsight(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: "40px" }}>
      <h1>Clueso Dashboard</h1>
      <p>You are logged in 🎉</p>

      {/* ACTION BUTTONS */}
      <div style={{ marginTop: "20px", display: "flex", gap: "12px" }}>
        <button onClick={() => navigate("/feedback")}>
          View Feedback
        </button>

        <button onClick={logout}>
          Logout
        </button>
      </div>

      {/* AI INSIGHTS SECTION */}
      <div style={{ marginTop: "40px" }}>
        <h2>AI Insights</h2>

        <button onClick={generateAIInsights} disabled={loading}>
          {loading ? "Analyzing..." : "Generate AI Insights"}
        </button>

        {error && (
          <p style={{ color: "red", marginTop: "10px" }}>
            {error}
          </p>
        )}

        {insight && (
          <div
            style={{
              marginTop: "20px",
              padding: "16px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              maxWidth: "500px"
            }}
          >
            <p><strong>Sentiment:</strong> {insight.sentiment}</p>
            <p><strong>Summary:</strong> {insight.summary}</p>
            <p><strong>Score:</strong> {insight.score}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;
