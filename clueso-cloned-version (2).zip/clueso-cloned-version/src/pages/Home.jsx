import Hero from "../components/Hero";
import Logos from "../components/Logos";
import Features from "../components/Features";
import Matrix from "../components/Matrix";
import CTA from "../components/CTA";
import Footer from "../components/Footer";

function Home() {
  return (
    <>
      <Hero />
      <Logos />
      <Features />
      <Matrix />
      <CTA />
      <Footer />
    </>
  );
}

export default Home;
